// Include original file, which was preprocessed, but original contains 
// #include statements that are required in final build.
#include "CBPlayer9.cpp"